from tkinter import *
from tkinter import messagebox,filedialog
from PIL import ImageTk, Image
import os,cv2,numpy as np
face = os.listdir('dataset') #[1000,2000,5000,10000,20000,50000,100000]
facedetect=cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
recognizer = cv2.face.LBPHFaceRecognizer_create()
def training():
    facemodels=[]
    ids = []
    cnt=0
    for v in face:
        PIL_img = Image.open(os.path.join('dataset/', v)).convert('L')  # Mengubah ke Grayscale
        img_numpy = np.array(PIL_img, 'uint8')
        id = int(os.path.split(v)[-1].split(".")[0])
        faces = facedetect.detectMultiScale(img_numpy)
        for (x, y, w, h) in faces:
            cv2.imshow('wajah',img_numpy[y:y + h, x:x + w])
            facemodels.append(img_numpy[y:y + h, x:x + w])
            ids.append(cnt)
        cnt+=1
    recognizer.train(facemodels,np.array(ids))
    recognizer.write('models.yml')
    messagebox.showinfo("Informasi", "Training telah berhasil!")

def detecting():
    recognizer.read('models.yml')
    path = filedialog.askopenfilename()
    img=cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = facedetect.detectMultiScale(gray,1.2,5,0,(40,40))
    for (x, y, w, h) in faces:
        id, confidence = recognizer.predict(gray[y:y + h, x:x + w])
        if (confidence < 100):
            id = face[id].split(".")[0]
        else:
            id = "Unknown"
    hasil.configure(text=str(id))
    image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    image=cv2.resize(image,(400,175))
    image = Image.fromarray(image)
    image = ImageTk.PhotoImage(image)
    picPanel.configure(image=image)
    picPanel.image = image

root = Tk()
root.title("Deteksi Mata Uang")
root.geometry('420x300')
root.eval('tk::PlaceWindow . center')
picPanel = Label(root, width= 400, borderwidth=2, relief='groove')
picPanel.place(x=10, y=60, width=400, height=175)
btn_training = Button(root, text="Training", command=training)
btn_training.place(x=10, y=25, width=75, height=20)
btn_detecting = Button(root, text="Detecting", command=detecting)
btn_detecting.place(x=100, y=25, width=75, height=20)
lbHasil = Label(text="Hasil Deteksi")
lbHasil.place(x = 10, y = 250 , width=75, height=25)
hasil = Label(root,text="",borderwidth=2, relief='groove')
hasil.place(x=85, y=250, width=100, height=20)
root.mainloop()