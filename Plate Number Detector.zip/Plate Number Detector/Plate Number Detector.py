from tkinter import *
from tkinter import filedialog
from PIL import ImageTk, Image
import cv2,pytesseract as pt

pt.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
cfg="--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
font=cv2.FONT_HERSHEY_SIMPLEX
def deteksi():
    path = filedialog.askopenfilename()
    if not path:
        return
    image=cv2.imread(path)
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    #cv2.imshow('hsv',hsv)
    mask = cv2.inRange(hsv, (0, 0, 218), (157, 54, 255)) #(B,G,R)
    # mask = cv2.inRange(hsv, (0, 0, 210), (157, 54, 255))
    # cv2.imshow('Mask',mask)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 3))
    dilate = cv2.dilate(mask, kernel, iterations=5)
    #cv2.imshow('dilate',dilate)
    cnts = cv2.findContours(dilate, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cnts = cnts[0] if len(cnts) == 2 else cnts[1]
    count = 0
    text=None
    for c in cnts:
        x, y, w, h = cv2.boundingRect(c)
        ar = w / float(h)
        count = count + 1
        #cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 3)
        if ar < 5:
            cv2.drawContours(dilate, [c], -1, (0, 0, 0), -1)
        if w >= h * 2.6 and w <= h * 3.5 and h>50 and h<130:
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 0, 255), 3) #red
            roi = image[y:y + h, x:x + w]
            #print(x,":",y,":",w,":",h)
            roi = cv2.resize(roi, dsize=None, fx=0.75, fy=0.75)
            #cv2.imshow('ROI',roi)
            if not text:
                text = pt.image_to_string(~roi, config=cfg)
    if text==None:
        text='Unknown'
    hasil.configure(text=text)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = cv2.resize(image,(400,300))
    image = Image.fromarray(image)
    image = ImageTk.PhotoImage(image)
    picPanel.configure(image=image)
    picPanel.image = image

root = Tk()
root.title("Deteksi Plat Nomor")
root.geometry('420x375')
root.eval('tk::PlaceWindow . center')
picPanel = Label(root, width= 400, borderwidth=2, relief='groove')
picPanel.place(x=10, y=30, width=400, height=300)
btn_detecting = Button(root, text="Deteksi", command=deteksi)
btn_detecting.place(x=10, y=5, width=75, height=20)
lbHasil = Label(text="Hasil Deteksi")
lbHasil.place(x = 10, y = 330 , width=75, height=25)
hasil = Label(root,text="",borderwidth=2, relief='groove')
hasil.place(x=85, y=330, width=100, height=50)
root.mainloop()