from tkinter import *
from tkinter import simpledialog,messagebox
from PIL import ImageTk, Image
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

import os,wave,time, pickle, pyaudio, warnings, numpy as np
import python_speech_features as mfcc
from sklearn import preprocessing
from sklearn.mixture import GaussianMixture
from scipy.io.wavfile import read
warnings.filterwarnings("ignore")
dataset_dir = "dataset"
models_dir = "models"
testing_file="testing.wav"
if not os.path.exists(dataset_dir): os.makedirs(dataset_dir)
if not os.path.exists(models_dir): os.makedirs(models_dir)


def visualize():
    raw = wave.open(testing_file)
    signal = raw.readframes(-1)
    signal = np.frombuffer(signal, dtype="int16")
    f_rate = raw.getframerate()
    time = np.linspace(0,len(signal) / f_rate,num=len(signal))
    f = Figure(figsize=(5, 4), dpi=100)
    plot=f.add_subplot(1,1,1)
    plot.plot(time,signal)
    plot.axis('off')
    canvas = FigureCanvasTkAgg(f, master=root)
    canvas.get_tk_widget().place(x=100, y=25, width=360, height=270)
    canvas.draw()

def calculate_delta(array):
    rows, cols = array.shape
    deltas = np.zeros((rows, 20))
    N = 2
    for i in range(rows):
        index = []
        j = 1
        while j <= N:
            if i-j < 0:
                first = 0
            else:
                first = i-j
            if i+j > rows-1:
                second = rows-1
            else:
                second = i+j
            index.append((second, first))
            j += 1
        deltas[i] = (array[index[0][0]]-array[index[0][1]] +(2 * (array[index[1][0]]-array[index[1][1]]))) / 10
    return deltas

def extract_features(audio, rate):
    mfcc_feature = mfcc.mfcc(audio, rate, 0.025, 0.01, 20, nfft=1200, appendEnergy=True)
    mfcc_feature = preprocessing.scale(mfcc_feature)
    delta = calculate_delta(mfcc_feature)
    combined = np.hstack((mfcc_feature, delta))
    return combined

def record_audio():
    FORMAT = pyaudio.paInt16; CHANNELS = 1; RATE = 44100; CHUNK = 512; RECORD_SECONDS = 5
    audio = pyaudio.PyAudio()
    stream = audio.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, input_device_index=1, frames_per_buffer=CHUNK)
    print("recording started : ")
    Recordframes = []
    for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
        data = stream.read(CHUNK)
        Recordframes.append(data)
    print("recording stopped")
    stream.stop_stream(); stream.close(); audio.terminate()
    OUTPUT_FILENAME = testing_file
    WAVE_OUTPUT_FILENAME = os.path.join(OUTPUT_FILENAME)
    waveFile = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
    waveFile.setnchannels(CHANNELS)
    waveFile.setsampwidth(audio.get_sample_size(FORMAT))
    waveFile.setframerate(RATE)
    waveFile.writeframes(b''.join(Recordframes))
    waveFile.close()

def dataset():
    name = simpledialog.askstring("Input Nama", "Masukkan Nama Anda!")
    if not name:
        messagebox.showinfo("Informasi", "Isikan Nama Anda!")
        return
    if not os.path.exists(dataset_dir+"/"+name):
        os.makedirs(dataset_dir+"/"+name)
    for count in range(5):
        FORMAT = pyaudio.paInt16; CHANNELS = 1; RATE = 44100; CHUNK = 512; RECORD_SECONDS = 5
        audio = pyaudio.PyAudio()
        stream = audio.open(format=FORMAT, channels=CHANNELS,rate=RATE, input=True, input_device_index=1,frames_per_buffer=CHUNK)
        print("Mulai : "+str(count))
        Recordframes = []
        for i in range(0, int(RATE / CHUNK * RECORD_SECONDS)):
            data = stream.read(CHUNK)
            Recordframes.append(data)
        print("Berhenti")
        stream.stop_stream();stream.close();audio.terminate()
        OUTPUT_FILENAME = dataset_dir+"/"+name+"/"+name+str(count)+".wav"
        WAVE_OUTPUT_FILENAME = os.path.join(OUTPUT_FILENAME)
        waveFile = wave.open(WAVE_OUTPUT_FILENAME, 'wb')
        waveFile.setnchannels(CHANNELS)
        waveFile.setsampwidth(audio.get_sample_size(FORMAT))
        waveFile.setframerate(RATE)
        waveFile.writeframes(b''.join(Recordframes))
        waveFile.close()
    messagebox.showinfo("Informasi", "Dataset " + name + " telah berhasil ditambahkan!")

def training():
    features = np.asarray(())
    for a in os.listdir(dataset_dir):
        count = 1
        for f in os.listdir(os.path.join(dataset_dir+'/', a)):
            sr,audio=read(dataset_dir+"/"+a+"/"+f)
            vector=extract_features(audio,sr)
            if features.size == 0:
                features = vector
            else:
                features = np.vstack((features, vector))
            if count == 5:
                gmm = GaussianMixture(n_components=6, max_iter=200, covariance_type='diag', n_init=3)
                gmm.fit(features)
                picklefile = models_dir+"/"+ a + ".gmm"
                pickle.dump(gmm, open(picklefile, 'wb'))
                features = np.asarray(())
                #count = 0
            count = count + 1
    messagebox.showinfo("Informasi", "Training "+str(count-1)+" Speakers telah berhasil!")

def deteksi():
    record_audio()
    visualize()
    gmm_files = [os.path.join(models_dir, fname) for fname in os.listdir(models_dir) if fname.endswith('.gmm')]
    models = [pickle.load(open(fname, 'rb')) for fname in gmm_files]
    speakers = os.listdir(dataset_dir)
    sr, audio = read(testing_file)
    vector = extract_features(audio, sr)
    log_likelihood = np.zeros(len(models))
    for i in range(len(models)):
        gmm = models[i]  # checking with each model one by one
        scores = np.array(gmm.score(vector))
        log_likelihood[i] = scores.sum()
    winner = np.argmax(log_likelihood)
    person.configure(text=speakers[winner])
    #print("Terdeteksi : ", speakers[winner])
    time.sleep(1.0)

root = Tk()
root.title("Speaker Recognition")
root.geometry('480x360')
root.eval('tk::PlaceWindow . center')
picPanel = Label(root, text='Preprocessed',borderwidth=2, relief='groove')
picPanel.place(x=100, y=25, width=360, height=270)
btn_dataset = Button(root, text="Dataset", command=dataset)
btn_dataset.place(x=15, y=25, width=75, height=20)
btn_training = Button(root, text="Training", command=training)
btn_training.place(x=15, y=50, width=75, height=20)
btn_detecting = Button(root, text="Deteksi", command=deteksi)
btn_detecting.place(x=15, y=75, width=75, height=20)
keterangan = Label(root,text="Deteksi")
keterangan.place(x=100, y=300, width=50, height=20)
person = Label(root,borderwidth=2, relief='groove')
person.place(x=150, y=300, width=100, height=20)
root.mainloop()