from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from time import sleep
from urllib.parse import quote
from os.path import expanduser

chrome_options = Options()
chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])
chrome_options.add_argument("--user-data-dir="+expanduser("~")+r"\AppData\Local\Google\Chrome\User Data\Default")

f = open("pesan.txt", "r")
message = f.read()
f.close()
print('Pesan:')
print(message)
message = quote(message)

numbers = []
nama=[]
f = open("hp.txt", "r")
for line in f.read().splitlines():
	if line!="":
		numbers.append(line)

f.close()
print('\nWe Ditemukan ' + str(len(numbers)) + ' Nomor Ponsel')
delay = 45

print('Setelah Web Browser Berjalan, pastikan anda Signin ke Whatsapp Web, selanjutnya tekan Enter')
driver = webdriver.Chrome(executable_path=r"chromedriver.exe", options=chrome_options)
driver.get('https://web.whatsapp.com')
input()
cnt=0
for number in numbers:
	if number == "":
		continue
	print('Mengirim Pesan ke: ' + number.split(',')[1])
	try:
		url = 'https://web.whatsapp.com/send?phone=' + number.split(',')[1] + '&text=Hai '+ number.split(',')[0]+'%0a' + message
		driver.get(url)
		click_btn = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.CLASS_NAME , '_1U1xa')))
		click_btn.click()
		sleep(30)
		print('Terkirim ke Nomor: ' + number.split(',')[1])
	except Exception:
		print('Gagal mengirim pesan ke Nomor: ' + number.split(',')[1])
	cnt += 1
driver.close()
