import speech_recognition as sr,pyttsx3
from googletrans import Translator
r = sr.Recognizer()
t = Translator()

def SpeakText(command):
    engine = pyttsx3.init()
    engine.say(command)
    engine.runAndWait()

mc = sr.Microphone()
with mc as source:
    print("Katakan 'mulai' untuk memulai")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    r.adjust_for_ambient_noise(source, duration=0.2)
    audio = r.listen(source)
    kode = r.recognize_google(audio,language="id-ID")
    kode = kode.lower()

if 'mulai' in kode:
    print('siap...')
    while (1):
        try:
            with sr.Microphone() as src:
                r.adjust_for_ambient_noise(src, duration=0.2)
                audio2 = r.listen(src)
                teks = r.recognize_google(audio2,language="id-ID")
                teks = teks.lower()
                trans=t.translate(teks,dest="en")
                print(teks+', EN:'+trans.text)
                SpeakText(trans.text)
        except sr.RequestError as e:
            print("Could not request results; {0}".format(e))
            break
        except sr.UnknownValueError:
            print("unknown error occured")
            break
