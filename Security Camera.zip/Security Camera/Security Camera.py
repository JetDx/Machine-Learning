import cv2,os
from datetime import datetime
if not os.path.exists('video'):
    os.makedirs('video')
subtractor = cv2.createBackgroundSubtractorMOG2()
fourcc = cv2.VideoWriter_fourcc('m', 'p', '4', 'v')
cap=cv2.VideoCapture(0)
now = datetime.now()
videomp4 = "video/"+now.strftime("%Y%m%d_%H%M%S")+'.mp4'
out = cv2.VideoWriter(videomp4, fourcc, 10, (640, 480))
while True:
    ret, frame = cap.read()
    process = frame
    mask = subtractor.apply(frame)
    mask = cv2.GaussianBlur(mask.copy(), (5, 5), 0)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, (5,5))
    mask = cv2.inRange(mask, 150, 220)
    conts, p = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    tampak = 0
    if len(conts)>0:
        for cnt in conts:
            if (cv2.contourArea(cnt) > 400):
                x, y, w, h = cv2.boundingRect(cnt)
                cv2.putText(frame, "Recording", (30, 30), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1,(0, 0, 255), 1, cv2.LINE_AA)
                timenow = datetime.now()
                cv2.putText(frame, timenow.strftime("%H:%M:%S.%f %d-%m-%Y"), (30, 450), cv2.FONT_HERSHEY_COMPLEX_SMALL, 0.8, (0, 0, 255), 1, cv2.LINE_AA)
                out.write(frame)
    else:
        out.release()
        out=None
        now = datetime.now()
        videomp4 = "video/"+now.strftime("%Y%m%d_%H%M%S") + '.mp4'
        out = cv2.VideoWriter(videomp4, fourcc, 10, (640, 480))
    cv2.imshow('img',frame)
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break
cap.release()
out.release()
cv2.destroyAllWindows()
for file in os.listdir("video"):
    if os.path.getsize("video/"+file) <= 100*1024: os.remove("video/"+file)
