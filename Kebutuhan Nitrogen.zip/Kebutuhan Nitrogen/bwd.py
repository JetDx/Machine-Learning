import cv2,math,numpy as np
from tkinter import *
from tkinter import filedialog
from PIL import ImageTk, Image

matrix = np.loadtxt('bwd.hist', usecols=range(256))

def distance(hist1,hist2):
    ed=0
    for i in range(255):
        ed=ed+(hist1[i]-hist2[i])**2 #euclidean distance
    return math.sqrt(ed)

def histogram(file):
    image = cv2.imread(file)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return cv2.calcHist([gray], [0], None, [256], [0, 255])
    #return cv2.calcHist([image], [0], None, [256], [0, 255])

def hitung():
    path = filedialog.askopenfilename()
    if not path:
        return
    image = cv2.imread(path)
    image = cv2.resize(image, (200, 200))
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    image = Image.fromarray(image)
    image = ImageTk.PhotoImage(image)
    Picture.configure(image=image)
    Picture.image = image
    hist_test=histogram(path)
    n=0
    min_dist=None
    kategori=0
    for f in range(4):
        dist=distance(matrix[f-1],hist_test)
        if min_dist==None:
            min_dist=dist
        if(dist<min_dist):
            min_dist=dist
            kategori=n+1
        n=n+1
    nitrogen = {1: "125 kg/ha",2: "100 kg/ha",3: "75 kg/ha",4: "50 kg/ha"}
    pil=nitrogen.get(kategori,'invalid')
    n_Kategori.config(text=str(kategori))
    n_Distance.config(text=str('{0:.2f}'.format(min_dist)))
    n_Nitrogen.config(text=pil)
    if kategori==0:
        n_Kategori.config(text='-')
        n_Distance.config(text='-')
        n_Nitrogen.config(text='-')

root = Tk()
root.title("Penentuan Jumlah Pupuk Nitrogen Berdasarkan BWD")
root.geometry('500x350')
root.eval('tk::PlaceWindow . center')

LbPicture = Label(text="Gambar Padi")
LbPicture.place(x = 25, y = 25 , width=75, height=25)
Picture = Label(text='Preprocessed',borderwidth=2, relief='groove')
Picture.place(x = 25, y = 50 , width=200, height=200)

LbAnalisa = Label(text="Hasil Analisa")
LbAnalisa.place(x = 275, y = 25 , width=75, height=25)

btn_file = Button(root, text="Open File", command=hitung)
btn_file.place(x = 25, y = 275 , width=75, height=20)

LbKategori = Label(text="Kategori")
LbKategori.place(x = 275, y = 50 , width=75, height=20)
n_Kategori = Label(borderwidth=2, relief='groove')
n_Kategori.place(x = 375, y = 50 , width=100, height=20)

LbDistance = Label(text="Distance")
LbDistance.place(x = 275, y = 75 , width=75, height=20)
n_Distance = Label(borderwidth=2, relief='groove')
n_Distance.place(x = 375, y = 75 , width=100, height=20)

LbNitrogen = Label(text="Nitrogen")
LbNitrogen.place(x = 275, y = 100 , width=75, height=20)
n_Nitrogen = Label(borderwidth=2, relief='groove')
n_Nitrogen.place(x = 375, y = 100 , width=100, height=20)
root.mainloop()