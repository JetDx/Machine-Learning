from tkinter import *
from tkinter import filedialog, messagebox
from PIL import ImageTk, Image
import os,cv2,numpy as np
from skimage.metrics import structural_similarity as ssim

disease = os.listdir('dataset') #nama-nama penyakit apa saja
def detecting():
    # Membaca File Model models.yml
    # Input File yang akan di deteksi
    path = filedialog.askopenfilename()
    if not path:
        return
    # Membaca File gambar dari yang diinput
    img = cv2.imread(path)
    #######
    # Mengubah dalam bentuk RGB
    imgg = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    imgg = Image.fromarray(imgg)
    imgg = ImageTk.PhotoImage(imgg)
    panelA.configure(image=imgg)
    panelA.image = imgg
    #######
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cur_hist=cv2.cv2.calcHist([gray], [0], None, [256], [0, 256])
    min_sim=None
    for v in disease:
        # Membaca file di folder disease
        for f in os.listdir(os.path.join('dataset/', v)):
            set_img=cv2.imread(os.path.join('dataset/', v, f))
            cv2.imshow('img',set_img)
            set_gray=cv2.cvtColor(set_img, cv2.COLOR_BGR2GRAY)
            (score, diff) = ssim(gray, set_gray, multichannel=True,full=True)
            print(v,":score=",score)
    #if confidence<100:
    #    hasil.configure(text=str(disease[id]))
    #else:
    #    hasil.configure(text='Tidak Terdeteksi')


root = Tk()
root.title("Skin Disease Detector")
root.geometry('400x350')
root.eval('tk::PlaceWindow . center')
labelA = Label(text="Picture")
labelA.place(x=25, y=25, width=50, height=20)
panelA = Label(text='preprocessed',borderwidth=2, relief='groove')
panelA.place(x=25, y=50, width=200, height=200)
btn_detecting = Button(root, text="Detect", command=detecting)
btn_detecting.place(x=25, y=300, width=75, height=20)

keterangan = Label(root,text='Prediksi')
keterangan.place(x=125, y=300, width=50, height=20)
hasil = Label(root,borderwidth=2, relief='groove')
hasil.place(x=175, y=300, width=100, height=20)
root.mainloop()
