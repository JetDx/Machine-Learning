import cv2,pafy
ip_camera="http://45.118.114.26/camera/"            # IP Camera Dinas Perhubungan Bandung
id_video=4                                        # ID Video Streaming
subtractor = cv2.createBackgroundSubtractorMOG2()   # Substract Background
font=cv2.FONT_HERSHEY_COMPLEX_SMALL                 # Setting Font

def open_streaming(id):
    file = open("cctv.yml", "r")
    content = file.read()
    return ip_camera+content.split("\n")[id]

cap=cv2.VideoCapture(open_streaming(id_video))
while True:
    ret,img=cap.read()
    mask = subtractor.apply(img)
    mask = cv2.GaussianBlur(mask.copy(), (5, 5), 0)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, (5, 5))
    mask = cv2.inRange(mask, 140, 255)
    cv2.imshow('Mask',mask)
    conts, p = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    for cnt in conts:
        x, y, w, h = cv2.boundingRect(cnt)
        if w>30 and h>30 and h<100 and w<100:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
    cv2.imshow('Monitoring! tekan [esc] untuk menutup!',img)
    k = cv2.waitKey(100) & 0xff                     # Tekan 'esc' untuk menutup
    if k == 27:
        break
cap.release()
cv2.destroyAllWindows()