import cv2, time
cap=cv2.VideoCapture("Traffic.mp4")
#cap=cv2.VideoCapture("http://atcs.banyumaskab.go.id/camera/sutosuman2.ts") # File Video
#car_cascade = cv2.CascadeClassifier('haarcascade_cars.xml')
car_cascade = cv2.CascadeClassifier('file.xml')
coord=[[175,130],[430,130],[150,150],[440,150]]
distance = 10 # 10 meter (perkiraan)
font=cv2.FONT_HERSHEY_COMPLEX_SMALL
while True:
    ret, img = cap.read()
    try:
        gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    except:
        continue
    warna=(0,0,255) #BGR Blue Green Red
    cv2.line(img, (coord[0][0],coord[0][1]),(coord[1][0],coord[1][1]),(0,0,255),2)   #Horizontal Atas
    cv2.line(img, (coord[0][0],coord[0][1]), (coord[2][0],coord[2][1]), (0, 0, 255), 2) #Vertical Kiri
    cv2.line(img, (coord[2][0],coord[2][1]), (coord[3][0], coord[3][1]), (0, 0, 255), 2) #Horizontal Bawah
    cv2.line(img, (coord[1][0],coord[1][1]), (coord[3][0], coord[3][1]), (0, 0, 255), 2) #Vertical Kanan
    #cars=car_cascade.detectMultiScale(gray,1.3,2,0,(60,60),(80,80))
    cars=car_cascade.detectMultiScale(gray,1.3,2)
    for (x, y, w, h) in cars:
        cv2.rectangle(img, (x, y), (x + w, y + h), (225, 0, 0), 2) #BGR
        if (y == coord[0][1]) or abs((y-coord[0][1]))<=1:
            cv2.line(img, (coord[0][0], coord[0][1]), (coord[1][0], coord[1][1]), (0, 255,0), 2) #Changes line color to green
            tim1= time.time()
        if (y == coord[2][1]) or abs((y-coord[2][1]))<1:
            cv2.line(img, (coord[2][0],coord[2][1]), (coord[3][0], coord[3][1]), (0, 0, 255), 2) #Changes line color to green
            tim2 = time.time()
            try:
                kec=int(distance/((tim2-tim1)/3600)/1000)
                if kec<100 and kec>10:
                    print("Kecepatan : ", kec, "km/jam")
            except:
                continue
        cv2.putText(img, str(x) , (x, y), font, 1, (255, 0, 0), 1, cv2.LINE_AA)
    cv2.imshow('img',img) #Shows the frame
    if cv2.waitKey(20) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()
