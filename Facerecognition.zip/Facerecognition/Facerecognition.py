from tkinter import *
from tkinter import simpledialog,messagebox
from PIL import ImageTk, Image
import os,cv2,numpy as np

if not os.path.exists('dataset'): # jika TIDAK ada Folder "Dataset"
    os.makedirs('dataset')        # maka buatlah folder dataset
face = os.listdir('dataset')
facedetect=cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
recognizer = cv2.face.LBPHFaceRecognizer_create()

def dataset():
    nama = simpledialog.askstring("Input Nama", "Masukkan Nama Anda!")
    if not nama:
        messagebox.showinfo("Informasi", "Isikan Nama Anda!")
        return
    cam = cv2.VideoCapture(0)
    cam.set(3, 360) # set lebar video
    cam.set(4, 270) # set tinggi video
    if not os.path.exists('dataset/'+nama):
            os.makedirs('dataset/'+nama.lower())
    count = 0
    while(True):
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = facedetect.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2)
            count += 1
            cv2.imwrite("dataset/" + str(nama) + '/' + str(count) + ".jpg", img[y:y+h,x:x+w])
            cv2.putText(img, str(count), (x + 5, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.imshow('img',img)
        k = cv2.waitKey(100) & 0xff  # Tekan 'ESC' untuk keluar dari Video
        if k == 27:
            break
        if count == 50: # Mengambil foto wajah sebanyak 50 dan menghentikan Video
            break
    cam.release()
    cv2.destroyAllWindows()
    messagebox.showinfo("Informasi", "Dataset "+nama+" telah berhasil ditambahkan!")

def training():
    face = os.listdir('dataset')
    facemodels=[]
    ids = []
    cnt=0
    for v in face:
        for f in os.listdir(os.path.join('dataset/', v)):
            PIL_img = Image.open(os.path.join('dataset/', v, f)).convert('L')  # Mengubah ke Grayscale
            img_numpy = np.array(PIL_img, 'uint8')
            faces = facedetect.detectMultiScale(img_numpy)
            for (x, y, w, h) in faces:
                facemodels.append(img_numpy[y:y + h, x:x + w])
                ids.append(cnt)
        cnt+=1
    recognizer.train(facemodels,np.array(ids))
    recognizer.write('models.yml')
    messagebox.showinfo("Informasi", "Training telah berhasil!")

def detecting():
    face = os.listdir('dataset')
    recognizer.read('models.yml')
    cam = cv2.VideoCapture(0)  # Memulai Capture Video Realtime
    cam.set(3, 480)  # set lebar video
    cam.set(4, 360)  # set tinggi video
    while (True):
        ret, img = cam.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = facedetect.detectMultiScale(gray,1.2,5,0,(40,40))
        for (x, y, w, h) in faces:
            id, confidence = recognizer.predict(gray[y:y + h, x:x + w])
            if (confidence < 100):
                id = face[id]
            else:
                id = "Unknown"
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 255), 2) # bukan RGB tapi BGR
            cv2.putText(img, id, (x + 5, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            cv2.imshow('img', img)
        k = cv2.waitKey(100) & 0xff  # Tekan 'ESC' untuk keluar dari Video
        if k == 27:
            break
    cam.release()
    cv2.destroyAllWindows()
    person.configure(text=str(id))
    image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    image = Image.fromarray(image)
    image = ImageTk.PhotoImage(image)
    picPanel.configure(image=image)
    picPanel.image = image

root = Tk()
root.title("Farerecognition")
root.geometry('480x360')
root.eval('tk::PlaceWindow . center')
picPanel = Label(root, text='Preprocessed',borderwidth=2, relief='groove')
picPanel.place(x=100, y=25, width=360, height=270)
btn_dataset = Button(root, text="Dataset", command=dataset)
btn_dataset.place(x=15, y=25, width=75, height=20)
btn_training = Button(root, text="Training", command=training)
btn_training.place(x=15, y=50, width=75, height=20)
btn_detecting = Button(root, text="Detecting", command=detecting)
btn_detecting.place(x=15, y=75, width=75, height=20)
keterangan = Label(root,text="Prediksi")
keterangan.place(x=100, y=300, width=50, height=20)
person = Label(root,borderwidth=2, relief='groove')
person.place(x=150, y=300, width=100, height=20)
root.mainloop()