import operator,winsound,cv2
import numpy as np

CONFIDENCE_THRESHOLD = 0.5
NMS_THRESHOLD = 0.4
cap = cv2.VideoCapture("pistol.mp4")
weights = "detector2.weights"
labels = "detector2.names"
cfg = "detector2.cfg"

class_names = list()
with open(labels, "r") as f:
    class_names = [cname.strip() for cname in f.readlines()]

COLORS = np.random.randint(0, 255, size=(len(class_names), 3), dtype="uint8")
net = cv2.dnn.readNetFromDarknet(cfg, weights)
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

layer = net.getLayerNames()
layer = [layer[i[0] - 1] for i in net.getUnconnectedOutLayers()]
writer = None

def detect_people(frm, net, ln):
    (H, W) = frm.shape[:2]
    blob = cv2.dnn.blobFromImage(frm, 1 / 255.0, (416, 416), swapRB=True, crop=False)
    net.setInput(blob)
    layerOutputs = net.forward(ln)
    boxes = []
    classIds = []
    confidences = []

    for output in layerOutputs:
        for detection in output:
            scores = detection[5:]
            classID = np.argmax(scores)
            confidence = scores[classID]

            if confidence > CONFIDENCE_THRESHOLD:
                box = detection[0:4] * np.array([W, H, W, H])
                (centerX, centerY, width, height) = box.astype("int")
                x = int(centerX - (width / 2))
                y = int(centerY - (height / 2))

                boxes.append([x, y, int(width), int(height)])
                classIds.append(classID)
                confidences.append(float(confidence))

    idxs = cv2.dnn.NMSBoxes(boxes, confidences, CONFIDENCE_THRESHOLD, NMS_THRESHOLD)
    if len(idxs) > 0:
        for i in idxs.flatten():
            (x, y) = (boxes[i][0], boxes[i][1])
            (w, h) = (boxes[i][2], boxes[i][3])
            label = str(class_names[classIds[i]])
            color = [int(c) for c in COLORS[classIds[i]]]
            senjata=['firearm','gun','knife','machete']
            if label in senjata:
                winsound.Beep(2500, 50)
                cv2.rectangle(frm, (x, y), (x + w, y + h), color, 2)
                cv2.putText(frm, label, (x, y + 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

while True:
    ret, img = cap.read()
    img=cv2.resize(img,(int(cap.get(3)*0.5),int(cap.get(4)*0.5)))
    detect_people(img, net, layer)
    cv2.imshow("detections", img)
    if (not ret) or (cv2.waitKey(29) & 0xFF == ord('q')):
        break

cap.release()
cv2.destroyAllWindows()
